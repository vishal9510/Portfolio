const express = require('express');
const app = express();
const bodyParser = require('body-parser');

const pr = (bodyParser.urlencoded({extended: true}));

app.set('view engine', 'ejs');
let user ='';
let userdata = [
    {
        id: 1,
        name: 'vishal',
    },
]

app.get('/todo', (req, res) => {
    res.render('index', {
        data: userdata,
        user: user,
    })
});

app.post('/savedata', pr, (req, res) => {
    let user1 ={
        id:userdata.length+1,
        name:req.body.name,
        
    }
    userdata.push(user1);
    res.redirect('/todo');
});

app.get('/del/:id', (req, res) => {
    let id = req.params.id;
    id = id - 1;
    userdata.splice(id, 1);
    let j = 1;
    userdata.forEach((i) => {
        i.id = j;
        j++;
    });
    res.redirect('/todo');
});
app.listen(8177);
